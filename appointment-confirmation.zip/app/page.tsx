"use client"

import CDAAppointmentForm from "../cda-appointment-form"

export default function SyntheticV0PageForDeployment() {
  return <CDAAppointmentForm />
}