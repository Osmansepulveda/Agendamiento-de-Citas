import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface CDAInfo {
  name: string
  logo: string
  address: string
  phone: string
  whatsapp: string
  vehicleTypes: string[]
  hours: {
    weekdays: string
    saturday: string
    sundayHolidays: string
  }
}

const cdaList: CDAInfo[] = [
  {
    name: "CDA La Belencita",
    logo: "/IMAGENES/Belencita logo.jpeg",
    address: "Dirección de La Belencita",
    phone: "Teléfono de La Belencita",
    whatsapp: "573015978100",
    vehicleTypes: ["Livianos", "Motos", "Pesados"],
    hours: {
      weekdays: "6:00 AM - 6:00 PM",
      saturday: "6:00 AM - 5:00 PM",
      sundayHolidays: "6:00 AM - 3:30 PM",
    },
  },
  {
    name: "CDA Los Patios",
    logo: "/IMAGENES/Los Patios logo.jpeg",
    address: "Dirección de Los Patios",
    phone: "Teléfono de Los Patios",
    whatsapp: "573212090034",
    vehicleTypes: ["Livianos"],
    hours: {
      weekdays: "6:00 AM - 6:30 PM",
      saturday: "6:30 AM - 5:00 PM",
      sundayHolidays: "7:30 AM - 4:00 PM",
    },
  },
  {
    name: "CDA Certimotos",
    logo: "/IMAGENES/Certimotos logo.jpeg",
    address: "Dirección de Certimotos",
    phone: "Teléfono de Certimotos",
    whatsapp: "573144622427",
    vehicleTypes: ["Motos"],
    hours: {
      weekdays: "6:30 AM - 6:30 PM",
      saturday: "7:00 AM - 5:00 PM",
      sundayHolidays: "8:00 AM - 4:00 PM",
    },
  },
  {
    name: "CDA Del Rio",
    logo: "/IMAGENES/Del Rio logo.jpeg",
    address: "Dirección de Del Rio",
    phone: "Teléfono de Del Rio",
    whatsapp: "57156127560",
    vehicleTypes: ["Livianos", "Motos", "Pesados", "Motocarros"],
    hours: {
      weekdays: "7:00 AM - 6:00 PM",
      saturday: "7:30 AM - 5:30 PM",
      sundayHolidays: "7:30 AM - 2:00 PM",
    },
  },
  {
    name: "CDA Plaza",
    logo: "/IMAGENES/Plaza logo.jpeg",
    address: "Dirección de Plaza",
    phone: "Teléfono de Plaza",
    whatsapp: "573025222221",
    vehicleTypes: ["Livianos", "Motos"],
    hours: {
      weekdays: "6:00 AM - 6:30 PM",
      saturday: "6:30 AM - 5:00 PM",
      sundayHolidays: "7:30 AM - 4:00 PM",
    },
  },
  {
    name: "CDA La Primera",
    logo: "/IMAGENES/La Primera logo.jpeg",
    address: "Dirección de La Primera",
    phone: "Teléfono de La Primera",
    whatsapp: "573225111073",
    vehicleTypes: ["Motos"],
    hours: {
      weekdays: "7:00 AM - 6:00 PM",
      saturday: "7:00 AM - 5:30 PM",
      sundayHolidays: "7:30 AM - 2:00 PM",
    },
  },
]

export default function CDAAppointmentForm() {
  const [selectedCDA, setSelectedCDA] = useState<CDAInfo | null>(null)

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    // Aquí iría la lógica para procesar el formulario
    console.log("Formulario enviado")
  }

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white shadow-lg rounded-lg">
      <h1 className="text-2xl font-bold text-center mb-6">Agendar Cita - Grupo Empresarial Certigases</h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <Label htmlFor="cda">Seleccione el CDA</Label>
          <Select onValueChange={(value) => setSelectedCDA(cdaList.find((cda) => cda.name === value) || null)}>
            <SelectTrigger id="cda">
              <SelectValue placeholder="Seleccione un CDA" />
            </SelectTrigger>
            <SelectContent>
              {cdaList.map((cda) => (
                <SelectItem key={cda.name} value={cda.name}>
                  {cda.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {selectedCDA && (
          <div className="bg-gray-100 p-4 rounded-lg">
            <img
              src={selectedCDA.logo || "/placeholder.svg"}
              alt={selectedCDA.name}
              className="w-32 h-auto mx-auto mb-4"
            />
            <p>
              <strong>Dirección:</strong> {selectedCDA.address}
            </p>
            <p>
              <strong>Teléfono:</strong> {selectedCDA.phone}
            </p>
            <p>
              <strong>Horario:</strong>
            </p>
            <ul className="list-disc list-inside">
              <li>Lunes a Viernes: {selectedCDA.hours.weekdays}</li>
              <li>Sábados: {selectedCDA.hours.saturday}</li>
              <li>Domingos y Festivos: {selectedCDA.hours.sundayHolidays}</li>
            </ul>
            <p>
              <strong>Tipos de vehículos:</strong> {selectedCDA.vehicleTypes.join(", ")}
            </p>
          </div>
        )}

        <div>
          <Label htmlFor="name">Nombre Completo</Label>
          <Input id="name" placeholder="Ingrese su nombre completo" required />
        </div>

        <div>
          <Label htmlFor="email">Correo Electrónico</Label>
          <Input id="email" type="email" placeholder="Ingrese su correo electrónico" required />
        </div>

        <div>
          <Label htmlFor="phone">Teléfono</Label>
          <Input id="phone" type="tel" placeholder="Ingrese su número de teléfono" required />
        </div>

        <div>
          <Label htmlFor="vehicleType">Tipo de Vehículo</Label>
          <Select disabled={!selectedCDA}>
            <SelectTrigger id="vehicleType">
              <SelectValue placeholder="Seleccione el tipo de vehículo" />
            </SelectTrigger>
            <SelectContent>
              {selectedCDA?.vehicleTypes.map((type) => (
                <SelectItem key={type} value={type}>
                  {type}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="plate">Placa del Vehículo</Label>
          <Input id="plate" placeholder="Ingrese la placa del vehículo" required />
        </div>

        <div>
          <Label htmlFor="date">Fecha Preferida</Label>
          <Input id="date" type="date" required />
        </div>

        <div>
          <Label htmlFor="time">Hora Preferida</Label>
          <Input id="time" type="time" required />
        </div>

        <Button type="submit" className="w-full">
          Agendar Cita
        </Button>
      </form>

      {selectedCDA && (
        <div className="mt-6 text-center">
          <p>¿Necesita ayuda? Contáctenos por WhatsApp:</p>
          <a
            href={`https://wa.me/${selectedCDA.whatsapp}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-green-500 text-white px-4 py-2 rounded-full mt-2 hover:bg-green-600 transition-colors"
          >
            Chatear por WhatsApp
          </a>
        </div>
      )}
    </div>
  )
}

