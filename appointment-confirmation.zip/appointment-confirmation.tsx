import { QrCode } from "lucide-react"
import { Button } from "@/components/ui/button"

interface AppointmentConfirmationProps {
  clientName: string
  appointmentDate: string
  appointmentTime: string
  serviceName: string
  companyName: string
  companyAddress: string
  companyPhone: string
}

export default function AppointmentConfirmation({
  clientName,
  appointmentDate,
  appointmentTime,
  serviceName,
  companyName,
  companyAddress,
  companyPhone,
}: AppointmentConfirmationProps) {
  return (
    <div className="max-w-2xl mx-auto p-6 bg-white shadow-lg rounded-lg print:shadow-none">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <div className="w-12 h-12 bg-gray-200 rounded-full mr-4"></div>
          <h1 className="text-2xl font-bold">{companyName}</h1>
        </div>
        <Button onClick={() => window.print()} className="print:hidden">
          Print
        </Button>
      </div>

      <div className="border-t border-b border-gray-200 py-4 mb-6">
        <h2 className="text-xl font-semibold mb-2">Appointment Confirmation</h2>
        <p className="text-gray-600">Thank you for scheduling an appointment with us!</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <h3 className="text-lg font-semibold mb-2">Client Information</h3>
          <p className="text-gray-700">Name: {clientName}</p>
        </div>
        <div>
          <h3 className="text-lg font-semibold mb-2">Appointment Details</h3>
          <p className="text-gray-700">Date: {appointmentDate}</p>
          <p className="text-gray-700">Time: {appointmentTime}</p>
          <p className="text-gray-700">Service: {serviceName}</p>
        </div>
      </div>

      <div className="flex justify-between items-center mb-6">
        <div>
          <h3 className="text-lg font-semibold mb-2">Location</h3>
          <p className="text-gray-700">{companyAddress}</p>
          <p className="text-gray-700">Phone: {companyPhone}</p>
        </div>
        <div className="flex flex-col items-center">
          <QrCode className="w-24 h-24 text-gray-400" />
          <p className="text-sm text-gray-500 mt-2">Scan for easy check-in</p>
        </div>
      </div>

      <div className="bg-gray-100 p-4 rounded-lg">
        <h3 className="text-lg font-semibold mb-2">Additional Information</h3>
        <ul className="list-disc list-inside text-gray-700">
          <li>Please arrive 10 minutes before your appointment time.</li>
          <li>If you need to reschedule, please call us at least 24 hours in advance.</li>
          <li>Don't forget to bring any relevant medical records or information.</li>
        </ul>
      </div>
    </div>
  )
}

