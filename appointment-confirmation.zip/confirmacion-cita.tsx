import { QrCode } from "lucide-react"
import { Button } from "@/components/ui/button"

interface ConfirmacionCitaProps {
  nombreCliente: string
  fechaCita: string
  horaCita: string
  tipoServicio: "Livianos" | "Moto" | "Pesado" | "Motocarro"
  placaVehiculo: string
}

export default function ConfirmacionCita({
  nombreCliente,
  fechaCita,
  horaCita,
  tipoServicio,
  placaVehiculo,
}: ConfirmacionCitaProps) {
  return (
    <div className="max-w-2xl mx-auto p-6 bg-white shadow-lg rounded-lg print:shadow-none">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <div className="w-12 h-12 bg-gray-200 rounded-full mr-4"></div>
          <h1 className="text-2xl font-bold">Grupo Empresarial Certigases</h1>
        </div>
        <Button onClick={() => window.print()} className="print:hidden">
          Imprimir
        </Button>
      </div>

      <div className="border-t border-b border-gray-200 py-4 mb-6">
        <h2 className="text-xl font-semibold mb-2">Confirmación de Cita</h2>
        <p className="text-gray-600">¡Gracias por agendar su cita con nosotros!</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <h3 className="text-lg font-semibold mb-2">Información del Cliente</h3>
          <p className="text-gray-700">Nombre: {nombreCliente}</p>
          <p className="text-gray-700">Placa del Vehículo: {placaVehiculo}</p>
        </div>
        <div>
          <h3 className="text-lg font-semibold mb-2">Detalles de la Cita</h3>
          <p className="text-gray-700">Fecha: {fechaCita}</p>
          <p className="text-gray-700">Hora: {horaCita}</p>
          <p className="text-gray-700">Servicio: {tipoServicio}</p>
        </div>
      </div>

      <div className="flex justify-between items-center mb-6">
        <div>
          <h3 className="text-lg font-semibold mb-2">Ubicación</h3>
          <p className="text-gray-700">CDA Certigases La Belencita</p>
          <p className="text-gray-700">Dirección: [Insertar dirección aquí]</p>
          <p className="text-gray-700">Teléfono: [Insertar teléfono aquí]</p>
        </div>
        <div className="flex flex-col items-center">
          <QrCode className="w-24 h-24 text-gray-400" />
          <p className="text-sm text-gray-500 mt-2">Escanear para fácil registro</p>
        </div>
      </div>

      <div className="bg-gray-100 p-4 rounded-lg">
        <h3 className="text-lg font-semibold mb-2">Información Adicional</h3>
        <ul className="list-disc list-inside text-gray-700">
          <li>Por favor, llegue 15 minutos antes de su hora de cita.</li>
          <li>Si necesita reprogramar, llámenos con al menos 24 horas de anticipación.</li>
          <li>Asegúrese de traer su licencia de conducir y tarjeta de propiedad del vehículo.</li>
          <li>El vehículo debe estar en condiciones de operación normal para la revisión.</li>
        </ul>
      </div>
    </div>
  )
}

